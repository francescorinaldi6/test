package com.example.prenotazione.dao;

import org.springframework.data.repository.CrudRepository;

import com.example.prenotazione.model.Conf_ufficio;

public interface Conf_ufficioDao  extends CrudRepository<Conf_ufficio, Integer>{

}
